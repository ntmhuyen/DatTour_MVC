﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProTechTiveGear.Models
{
	public class CustomerEntity
	{
		public string Username { get; set; }
		public CustomerEntity(Customer cs)
		{
			

		}
	}
}